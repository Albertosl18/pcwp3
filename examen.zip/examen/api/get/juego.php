<?php
// FICHERO: api/get/juego.php
// PETICIONES GET ADMITIDAS:
//   api/juego/{NUM_TUBOS} -> devuelve la configuración inicial de bolas para los tubos.
//                            {NUM_TUBOS} indica el número de tubos a utilizar en el juego.
//                            Si no se indica, el número de tubos por defecto es 5
// =================================================================================
// RECURSO
// =================================================================================
if(strlen($_GET['prm']) > 0)
    $RECURSO = explode("/", substr($_GET['prm'],1));
else
    $RECURSO = [];
// =================================================================================
// PARÁMETROS DE CONFIGURACIÓN
// =================================================================================
$N_BOLAS = 4; // Se suponen cuatro bolas por color
$N_TUBOS = array_shift($RECURSO); // Se pilla el número de tubos de la petición
if(!is_numeric($N_TUBOS)) // Si no se indicó el número de tubos, se utilizan un valor por defecto
    $N_TUBOS = 5;
$N_COLORES      = max($N_TUBOS - 2,2);
$N_TUBOS_VACIOS = $N_TUBOS % $N_COLORES;
// =================================================================================
// CONFIGURACION DE SALIDA JSON Y CORS PARA PETICIONES AJAX
// =================================================================================
header("Access-Control-Allow-Orgin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
// =================================================================================
// INICIALIZACIÓN DE LOS TUBOS
// =================================================================================
$TUBOS = []; // Tubos a utilizar
for($i=0;$i<$N_TUBOS;$i++)
{
  $TUBOS[] = [];
  if($i>=$N_TUBOS-$N_TUBOS_VACIOS)
      for($j=0;$j<$N_BOLAS;$j++)
        array_push($TUBOS[$i], 0);
}
// =================================================================================
// SE RELLENAN LOS TUBOS CON LAS BOLAS DE FORMA ALEATORIA
// =================================================================================
for($i=0;$i<$N_COLORES;$i++)
{
    for($j=0;$j<$N_BOLAS;$j++)
    {
        // Se elige un tubo de forma aleatoria
        do{
            $TUBO = rand(0,$N_TUBOS-$N_TUBOS_VACIOS - 1);
        }while(count($TUBOS[$TUBO]) >= $N_BOLAS);
        array_push($TUBOS[$TUBO], $i+1);
    }
}
// Se hacen intercambios aleatorios
$N_INTERCAMBIOS = $N_BOLAS * $N_COLORES;
for($i=0;$i<$N_INTERCAMBIOS;$i++)
{
    $tubo_orig = rand(0,$N_TUBOS-$N_TUBOS_VACIOS - 1);
    $bola_orig = rand(0,$N_BOLAS - 1);
    $tubo_dest = rand(0,$N_TUBOS-$N_TUBOS_VACIOS - 1);
    $bola_dest = rand(0,$N_BOLAS - 1);
    $bola_aux  = $TUBOS[$tubo_dest][$bola_dest];
    $TUBOS[$tubo_dest][$bola_dest] = $TUBOS[$tubo_orig][$bola_orig];
    $TUBOS[$tubo_orig][$bola_orig] = $bola_aux;
}
// =================================================================================
// RESPUESTA
// =================================================================================
$RESPONSE_CODE  = 200; // código de respuesta por defecto: 200 - OK
$R              = [];  // Almacenará el resultado.
$R['CODIGO']    = $RESPONSE_CODE;
$R['RESULTADO'] = 'OK';
$R['TUBOS']     = $TUBOS; // Configuración de tubos para el juego
// =================================================================================
// SE DEVUELVE EL RESULTADO DE LA CONSULTA
// =================================================================================
http_response_code($RESPONSE_CODE);
echo json_encode($R);
?>