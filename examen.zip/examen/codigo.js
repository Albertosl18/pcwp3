function lanzadera() {
    cargar();
    prepararCanvas();
    prepararCanvas2();
    prepararCanvas3();
    prepararCanvas4();
    prepararCanvas5();
    ponerfondo();
}
function cargar(){
    let url = 'api/juego';
    fetch(url).then(function (respuesta) {
        if (respuesta.ok) {
            respuesta.json().then(function (datos) {
                console.log(datos);
            });
        } else {
            console.log('Error ' + respuesta.status + ': ' + respuesta.statusText);
        }
    }).catch(function (error) {
        console.log('Fetch Error: ', error);
    });
}
function prepararCanvas() {
    let cv = document.querySelector('#cv01');

    cv.width = 100;
    cv.height = 200;
}
function prepararCanvas2() {
    let cv = document.querySelector('#cv02');

    cv.width = 100;
    cv.height = 200;
}
function prepararCanvas3() {
    let cv = document.querySelector('#cv03');

    cv.width = 100;
    cv.height = 200;
}
function prepararCanvas4() {
    let cv = document.querySelector('#cv04');

    cv.width = 100;
    cv.height = 200;
}
function prepararCanvas5() {
    let cv = document.querySelector('#cv05');

    cv.width = 100;
    cv.height = 200;
}


function ponerfondo() {//dibujo en 2d: Cuadrado
    let cv = document.querySelector('#cv01'),
        ctx = cv.getContext('2d');

    ctx.fillStyle = '#4ACFFFFF';//para llenar algo de un color
    ctx.fillRect(1, 1, cv.with, cv.height);//paraa hacer la figura
}